create function ConvDeleteProduct(hId int)
  returns int
  BEGIN

delete  r.*,d.*
FROM fedalb.HOTEL h, PRODUCT p, CANCELPOLICYPLAN cpp, PRODUCT_REL_ROOMCATEGORY prc, ROOMCATEGORY r, DBDAVAILPLAN d, DBDBASEPRICEPLAN dp
where h.id = hId and p.Name = "Prodotto Convenzioni" and p.HotelId = h.Id and cpp.HotelId = p.HotelId and prc.ProductId = p.Id and r.id = prc.RoomCategoryId and d.Id = r.DbdAvailPlanId and dp.HotelId = p.HotelId; 

delete p.* from PRODUCT p
where p.Name = "Prodotto Convenzioni" and p.hotelId = hId;
 
delete dp.* from DBDBASEPRICEPLAN dp
where Name = "listino convenzioni" and dp.hotelId = hId;

delete cpp.* from CANCELPOLICYPLAN cpp
where Name = "cancellazione convenzione" and cpp.hotelId = hId;
RETURN hId;
END;

